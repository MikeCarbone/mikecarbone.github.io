//
//  ViewController.swift
//  HabitBreaker
//
//  Created by Mike Carbone on 1/21/19.
//  Copyright © 2019 Mike Carbone. All rights reserved.
//

import UIKit
//A/V foundation library
import AVFoundation

import CoreData

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.boom()
    }
    
    func boom(){
        print("BOOM")
        
            
        var _ = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) {
                (_) in
                
                
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                let context = appDelegate.persistentContainer.viewContext
                let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Habit")
                request.returnsObjectsAsFaults = false
                do {
                    let result = try context.fetch(request)
                    var dataEntryCount = 0
                    
                    for data in result as! [NSManagedObject] {
                        print(data)
                        dataEntryCount = dataEntryCount + 1
                    }
                    
                    let bla = result as! [NSManagedObject]
                    let hehe = bla[dataEntryCount - 1].value(forKey: "habitStart")
                    
                    let newHabit1 = bla[dataEntryCount - 1].value(forKey: "habitName")
                    let newHabit = newHabit1 as! String

                    print("New habit: \(newHabit)")
                    
                    self.habitLabel.text = "Breaking the habit \(newHabit)"
                   

                    let currentDateTime = Date()
                    
                    let formatter = DateFormatter()
                    // initially set the format based on your datepicker date / server String
                    formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                    
                    let myString = formatter.string(from: currentDateTime) // string purpose I add here
                    // convert your string to date
                    let yourDate = formatter.date(from: myString)
                    //then again set the date format whhich type of output you need
                    formatter.dateFormat = "HH:mm:ss"
                    // again convert your date to string
                    let dateString = formatter.string(from: yourDate!)
                    let currentSec = String(dateString.suffix(2))
                    var currentMin = String(dateString.prefix(5))
                    currentMin = String(currentMin.suffix(2))
                    let currentHour = String(dateString.prefix(2))
                    
                    
                    let currentHourNum = Int(currentHour) ?? 0
                    let currentMinNum = Int(currentMin) ?? 0
                    let currentSecNum = Int(currentSec) ?? 0
                    
                    formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                    let newHehe = formatter.string(from: hehe as! Date)
                    let storedDate = formatter.date(from: newHehe)
                    formatter.dateFormat = "HH:mm:ss"
                    let storedDateString = formatter.string(from: storedDate!)
                    print(storedDateString)
                    let storedSec = String(storedDateString.suffix(2))
                    var storedMin = String(storedDateString.prefix(5))
                    storedMin = String(storedMin.suffix(2))
                    let storedHour = String(storedDateString.prefix(2))
                    
                    let storedHourNum = Int(storedHour) ?? 0
                    let storedMinNum = Int(storedMin) ?? 0
                    let storedSecNum = Int(storedSec) ?? 0
                    
                    
                    print(currentDateTime)
                    print(currentHourNum, storedHourNum)
                    print(currentMinNum, storedMinNum)
                    if ((currentHourNum == storedHourNum) && (currentMinNum == storedMinNum)){
                        if (abs(currentSecNum - storedSecNum) == 1){
                            self.numberUnit.text = "SECOND"
                        } else {
                          self.numberUnit.text = "SECONDS"
                        }
                        
                        let bigNum = abs(currentSecNum - storedSecNum)
                        let bigNumString = String(bigNum)
                        print(bigNumString)
                        self.bigNumber.text = bigNumString
                    }
                    
                    if ((currentHourNum == storedHourNum) && (currentMinNum != storedMinNum)){
                        if(abs(currentMinNum - storedMinNum) == 1){
                            self.numberUnit.text = "MINUTE"
                        } else{
                            self.numberUnit.text = "MINUTES"
                        }
                        
                        let bigNum = abs(currentMinNum - storedMinNum)
                        let bigNumString = String(bigNum)
                        print(bigNumString)
                        self.bigNumber.text = bigNumString
                    }
                
                
                //if day different, days
                //if hour different, hours
                //if all same, seconds
                
                
                
                
                //                let formatter2 = DateFormatter()
                //                formatter2.dateFormat = "yyyy-MM-dd HH:mm:ss"
                //                let myString2 = formatter2.string(from: hehe)
                //                let yourDate2 = formatter2.date(from: myString2)
                //                formatter2.dateFormat = "HH:mm:ss"
                //                let storedDate2 = formatter2.string(from: yourDate2!)
                //                let storedHour = String(storedDate2.prefix(2))
                //                let storedHourNum = Int(storedHour)
                ////                print(currentDateTime)
                ////                print(hehe ?? 0)
                //
                //                print(a - storedHourNum)
                
                } catch {
                    print("Failed")
            }
        }
    }
    

    var player = AVAudioPlayer()
    
    @IBOutlet weak var bigNumber: UILabel!
    @IBOutlet weak var numberUnit: UILabel!
    @IBOutlet weak var habitLabel: UILabel!
    
    @IBAction func Audio2(_ sender: Any) {
        
        
        
        print("Button clicked!")
        
        let path = Bundle.main.path(forResource: "success", ofType : "mp3")!
        let url = URL(fileURLWithPath : path)
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player.play()
            
        } catch {
            
            print ("There is an issue with this code!")
            
        }
        
        //1. Create the alert controller.
        let alert = UIAlertController(title: "Start a New Streak", message: "What habit are you breaking?", preferredStyle: .alert)
        
        //2. Add the text field. You can configure it however you need.
        alert.addTextField { (textField) in
            textField.text = "Drinking soda"
        }
        
        // 3. Grab the value from the text field, and print it when the user clicks OK.
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
            //This unwraps for the code below idk thanks kevin
            guard let alert = alert else { return }
            
            let textField = alert.textFields![0] // Force unwrapping because we know it exists.
            
            let newHabit = textField.text!
            let newHabitDate = Date()
            
            print("Text field: \(newHabit)")
            print("Date: \(newHabitDate)")
            
            self.habitLabel.text = "Breaking the habit \(newHabit)"
            
            //Reset clock to 0
            self.bigNumber.text = "0"
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            let context = appDelegate.persistentContainer.viewContext

            let entity = NSEntityDescription.entity(forEntityName: "Habit", in: context)
            
            let newHabitObj = NSManagedObject(entity: entity!, insertInto: context)
            
            newHabitObj.setValue(newHabit, forKey: "habitName")
            newHabitObj.setValue(newHabitDate, forKey: "habitStart")
            
            do {
                try context.save()
                self.boom()
            } catch {
                print("Failed saving")
            }
            
            
            
            //Store the day started and the name
            //Loop, count the difference
            //If less than 60, have it be seconds
            //If currentDay - startedDay is longer than longest streak, replace text on other screen
            
            
            
            
            
            
        }))
        
        // 4. Present the alert.
        self.present(alert, animated: true, completion: nil)

    }
}


