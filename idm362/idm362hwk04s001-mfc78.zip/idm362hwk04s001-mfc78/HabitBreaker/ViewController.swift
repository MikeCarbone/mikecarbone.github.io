//
//  ViewController.swift
//  HabitBreaker
//
//  Created by Mike Carbone on 1/21/19.
//  Copyright © 2019 Mike Carbone. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func NewStreak(_ sender: UIButton, forEvent event: UIEvent) {
    
        //Creates object, doesnt put it on screen
        let myAlertObj = UIAlertController(title: "Delete all records?", message: "Are you sure?", preferredStyle: .alert)
        
        //Add alert button
        myAlertObj.addAction(UIAlertAction(
            title: "Cancel",
            style: .cancel,
            handler: {
                (UIAlertAction) in print("User Cancelled")
        }
        ))
        
        //Instantiate alert
        self.present(myAlertObj, animated: true)

    }
}


