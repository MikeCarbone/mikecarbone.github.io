//
//  ViewController.swift
//  HabitBreaker
//
//  Created by Mike Carbone on 1/21/19.
//  Copyright © 2019 Mike Carbone. All rights reserved.
//

import UIKit
//A/V foundation library
import AVFoundation

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    

    var player = AVAudioPlayer()
    
    @IBAction func Audio2(_ sender: Any) {
        print("Button clicked!")
        
        let path = Bundle.main.path(forResource: "success", ofType : "mp3")!
        let url = URL(fileURLWithPath : path)
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player.play()
            
        } catch {
            
            print ("There is an issue with this code!")
            
        }
        
//        //Creates object, doesnt put it on screen
        let myAlertObj = UIAlertController(title: "Start new streak!", message: "Enter the title of your new streak", preferredStyle: .alert)
//
//        //Add alert button
        myAlertObj.addAction(UIAlertAction(
            title: "Cancel",
            style: .destructive,
            handler: {
                (UIAlertAction) in print("User Cancelled")
        }
        ))
//
        myAlertObj.addAction(UIAlertAction(
            title: "Start",
            style: .default,
            handler: {
                (UIAlertAction) in print("User Cancelled")
        }
        ))
//
        //Instantiate alert
        self.present(myAlertObj, animated: true)

    }
}


